/** ****************** * Color Mode Button * ****************** **/


document.addEventListener('DOMContentLoaded', function() {
	var colormodeTrigger = document.querySelector('.js-mode');
	var themeIcon = document.getElementById('theme-icon'); 

	if (colormodeTrigger && themeIcon) {
		colormodeTrigger.addEventListener('click', function() {
			document.body.classList.toggle('dark-mode');

			if (document.body.classList.contains('dark-mode')) {
				themeIcon.src = 'images/dark.png';
			} else {
				themeIcon.src = 'images/light.png';
			}
		});
	}
});
